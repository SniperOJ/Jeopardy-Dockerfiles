<?php
die("error!");
?>