<?php
/*
* Author: [ Copy Lian ]
* Date: [ 2015.05.08 ]
* Description [ 行为配置 ]
*/
return array(
     'app_begin' => array('Behavior\CheckLangBehavior'),
);
?>