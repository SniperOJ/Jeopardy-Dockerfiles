<?php
/*
*Author:lianlincheng
*Date:2016-06-15 14:08:29
*/
return array(
	'MESSAGE_ACCOUT'=>'cf_copylian', // 账号
	'MESSAGE_PASSWORD'=>'1818181818', // 密码
	'MESSAGE_CODELENTH'=>6, // 验证码长度
	'MESSAGE_TYPE'=>1, // 类型
	'MESSAGE_APPLYNAME'=>'互亿无线', // 提供商
	'MESSAGE_APPLYURL'=>'http://www.ihuyi.com/', // 提供商url
	'MESSAGE_CONTENT'=>'您的验证码是：{$code}。请不要把验证码泄露给其他人。', // 短信模板
	'MESSAGE_STATUS'=>1, // 状态
);
?>