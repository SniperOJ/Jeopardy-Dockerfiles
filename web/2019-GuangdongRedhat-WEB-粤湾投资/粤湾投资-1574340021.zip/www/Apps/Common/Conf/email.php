<?php
/*
*Author:lianlincheng
*Date:2016-05-11 13:32:01
*/
return array(
	'MAIL_ADDRESS'=>'lianlincheng@163.com', // 邮箱地址
	'MAIL_SMTP'=>'smtp.163.com', // 邮箱SMTP服务器
	'MAIL_LOGINNAME'=>'lianlincheng@163.com', // 邮箱登录帐号
	'MAIL_PASSWORD'=>'llc1818818118llc', // 邮箱密码
	'MAIL_PORT'=>'25', // smtp端口号
	'MAIL_FROMUSERNAME'=>'爱客猴', // 发件人
	'MAIL_MOBAN'=>'您好：{$username}，您通过邮件在本站找回密码，系统已经将您的密码重置为：{$password}，此用户已经被锁定，请点击以下链接激活激活账户：{$url}', // 邮件配置模板
	'MAIL_STATUS'=>1 // 邮件配置状态
);
?>